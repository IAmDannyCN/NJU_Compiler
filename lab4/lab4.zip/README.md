## Usage

Compile lab 3 with `make` at `./Code`, `parser` will be generated.

Use `parser xxx.cmm yyy.ir` to run lex/syntax/semantic check for `xxx.cmm`, then generate intermediate code `yyy.ir`.

## Update Log

**2024.11.15**

Lab 3: Code Completed. Unknown bugs remain to fix.

Score: 94/100

**2024.11.20**

Lab 3: Code Completed. Previous bugs are caused by not handling the direct assignment between arrays.

Score: 100/100