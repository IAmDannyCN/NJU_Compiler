## Usage

Compile lab 1 with `make` at `./Code`.

## Update Log

**2024.10.8**

Lab 1 finished with report.

Score: 96/100.